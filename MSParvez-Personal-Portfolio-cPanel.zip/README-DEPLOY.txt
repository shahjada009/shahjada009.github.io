SHAHJADA PARVEZ — MSPARVEZ.ME PERSONAL PORTFOLIO
=================================================

DEPLOY ON CPANEL
1. In cPanel File Manager, locate the document root for msparvez.me.
   Often this is public_html, but addon domains may use another folder.
2. Back up the existing site before replacing files.
3. Upload the contents of this ZIP and extract in the domain document root.
4. The document root must contain index.html, assets/, robots.txt, sitemap.xml.
5. Visit https://msparvez.me and hard-refresh if you see a cached page.
6. Enable a valid HTTPS certificate in cPanel (AutoSSL or hosting provider SSL).

EDIT CONTENT
- Main copy, projects, link URLs, SEO text: index.html
- Site appearance: assets/styles.css
- Canvas 0/1 effects, mobile navigation, terminal: assets/script.js
- Brandmark: assets/favicon.svg
- Social preview image: assets/og-cover.png

IMPORTANT CONTENT NOTES
- NEXT-CRM, Sovranio AI and HexWisp are presented as work in progress.
- The TNEM work is explicitly described as a research proposal, not verified results.
- No photograph, CV, employer, client roster, social handles or degree awards
  have been invented. Add them when you have verified details.
- Contact uses the email previously supplied by the site owner:
  shahjada009@gmail.com
- The contact action uses email links, with no server-side form or email collection.
- External project URLs: demo.sovranio.com, sovranio.com and hexwisp.com.

The layout works as a static site: HTML + CSS + vanilla JavaScript.
No Node.js server, database, npm install, or build process is needed.
